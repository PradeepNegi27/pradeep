
from dotenv import load_dotenv
load_dotenv()

from crewai import Agent
from tools import BloodTestReportTool
from langchain.chat_models import ChatOpenAI

llm = ChatOpenAI(temperature=0.7, model_name="gpt-4")

doctor = Agent(
    role="Senior Medical Doctor",
    goal="Provide accurate medical advice based on symptoms and reports.",
    verbose=True,
    memory=True,
    backstory="Experienced physician with focus on diagnosis.",
    tools=[BloodTestReportTool().read_data_tool],
    llm=llm,
    max_iter=2,
    max_rpm=1,
    allow_delegation=True
)

verifier = Agent(
    role="Blood Report Verifier",
    goal="Verify authenticity and content of blood reports.",
    verbose=True,
    memory=True,
    backstory="Skilled lab specialist.",
    tools=[BloodTestReportTool().read_data_tool],
    llm=llm,
    max_iter=2,
    max_rpm=1,
    allow_delegation=False
)

nutritionist = Agent(
    role="Clinical Nutritionist",
    goal="Offer nutrition advice based on blood tests.",
    verbose=True,
    memory=True,
    backstory="Certified with 15+ years of experience.",
    tools=[BloodTestReportTool().read_data_tool],
    llm=llm,
    max_iter=2,
    max_rpm=1,
    allow_delegation=False
)

exercise_specialist = Agent(
    role="Fitness and Wellness Coach",
    goal="Design fitness plans based on health data.",
    verbose=True,
    memory=True,
    backstory="Certified in personalized training routines.",
    tools=[],
    llm=llm,
    max_iter=2,
    max_rpm=1,
    allow_delegation=False
)
