
import os
from dotenv import load_dotenv
load_dotenv()


from langchain.document_loaders import PyPDFLoader



class BloodTestReportTool:
    @staticmethod
    def read_data_tool(path='data/sample.pdf'):
        docs = PyPDFLoader(file_path=path).load()

        full_report = ""
        for data in docs:
            content = data.page_content.replace("\n\n", "\n")
            full_report += content + "\n"
        return full_report
