
from crewai import Task
from agents import doctor, verifier, nutritionist, exercise_specialist
from tools import BloodTestReportTool

blood_report_tool = BloodTestReportTool().read_data_tool

help_patients = Task(
    description="Analyze the query and blood test to provide medical advice.",
    expected_output="Detailed medical analysis based on query and blood values.",
    agent=doctor,
    tools=[blood_report_tool],
    async_execution=False
)

nutrition_analysis = Task(
    description="Provide nutrition guidance based on blood report.",
    expected_output="Personalized diet and supplement recommendations.",
    agent=nutritionist,
    tools=[blood_report_tool],
    async_execution=False
)

exercise_planning = Task(
    description="Create safe, effective exercise plan from blood report insights.",
    expected_output="Customized fitness plan matching health profile.",
    agent=exercise_specialist,
    tools=[blood_report_tool],
    async_execution=False
)

verification = Task(
    description="Verify and summarize uploaded blood report.",
    expected_output="Report validity, key biomarkers, clinical context.",
    agent=verifier,
    tools=[blood_report_tool],
    async_execution=False
)
